#!/bin/sh
TCPDUMP_ROOT="/usr"
export PATH="$TCPDUMP_ROOT/sbin:$PATH"
if [ "static" = "dynamic" ]; then
  export LD_LIBRARY_PATH="$TCPDUMP_ROOT/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi

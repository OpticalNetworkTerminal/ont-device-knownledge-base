#!/bin/sh
set -eu

die(){ echo "ERROR: $*" >&2; exit 1; }

usage(){
cat <<'USAGE'
Usage:
  start-shellinabox.sh [options] [-- SHELLINABOXD_ARGS...]

Options:
  --listen 0.0.0.0|127.0.0.1
  --port PORT
  --service SERVICE
  --cert-dir PATH
  --pidfile PATH
  --user USER
  --group GROUP
  --disable-ssl

Examples:
  start-shellinabox.sh --listen 0.0.0.0 --port 4200
  start-shellinabox.sh --service '/:root:root:/:/bin/sh'
USAGE
}

listen=""
port="4200"
service="/:LOGIN"
cert_dir="/etc/shellinabox"
pidfile="/tmp/shellinaboxd.pid"
user=""
group=""
ssl="yes"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --listen) [ "$#" -ge 2 ] || die "--listen requires an argument"; listen="$2"; shift 2 ;;
    --port)
      [ "$#" -ge 2 ] || die "--port requires an argument"
      port="$2"
      case "$port" in ''|*[!0-9]*) die "--port must be numeric" ;; esac
      shift 2
      ;;
    --service) [ "$#" -ge 2 ] || die "--service requires an argument"; service="$2"; shift 2 ;;
    --cert-dir) [ "$#" -ge 2 ] || die "--cert-dir requires an argument"; cert_dir="$2"; shift 2 ;;
    --pidfile) [ "$#" -ge 2 ] || die "--pidfile requires an argument"; pidfile="$2"; shift 2 ;;
    --user) [ "$#" -ge 2 ] || die "--user requires an argument"; user="$2"; shift 2 ;;
    --group) [ "$#" -ge 2 ] || die "--group requires an argument"; group="$2"; shift 2 ;;
    --disable-ssl) ssl="no"; shift ;;
    -h|--help) usage; exit 0 ;;
    --) shift; break ;;
    *) die "unknown option: $1" ;;
  esac
done

mkdir -p "$cert_dir"

set -- --port="$port" --service="$service" --pidfile="$pidfile" "$@"
case "$listen" in
  ""|0.0.0.0|::) ;;
  127.0.0.1|localhost|::1) set -- --localhost-only "$@" ;;
  *) die "shellinaboxd does not support binding an arbitrary IP; use 0.0.0.0 for all interfaces or 127.0.0.1 for loopback" ;;
esac
[ "$ssl" = yes ] && set -- --cert="$cert_dir" "$@"
[ "$ssl" = no ] && set -- --disable-ssl "$@"
[ -n "$user" ] && set -- --user="$user" "$@"
[ -n "$group" ] && set -- --group="$group" "$@"

exec "/usr/bin/shellinaboxd" "$@"

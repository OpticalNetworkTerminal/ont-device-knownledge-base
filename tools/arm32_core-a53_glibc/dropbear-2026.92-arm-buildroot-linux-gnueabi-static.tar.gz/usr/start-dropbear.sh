#!/bin/sh
set -eu

die(){ echo "ERROR: $*" >&2; exit 1; }

usage(){
cat <<'USAGE'
Usage:
  start-dropbear.sh [options] [-- DROPBEAR_ARGS...]

Options:
  --listen IP
  --port PORT
  --hostkey-dir PATH
  --authorized-keys PATH
  --root-home PATH
  --sftp-server PATH
  --pidfile PATH
  --password-auth yes|no
  --root-password-auth yes|no

Examples:
  start-dropbear.sh
  start-dropbear.sh --listen 192.168.1.1 --port 2224
  start-dropbear.sh --sftp-server /usr/libexec/sftp-server
USAGE
}

hostkey_dir="/etc/dropbear"
authorized_keys="/root/.ssh/authorized_keys"
root_home="/root"
sftp_server="/usr/libexec/sftp-server"
compiled_sftp_server="/usr/libexec/sftp-server"
pidfile="/tmp/dropbear.pid"
listen=""
port="22"
password_auth="no"
root_password_auth="no"

while [ "$#" -gt 0 ]; do
  case "$1" in
    --listen) [ "$#" -ge 2 ] || die "--listen requires an argument"; listen="$2"; shift 2 ;;
    --port)
      [ "$#" -ge 2 ] || die "--port requires an argument"
      port="$2"
      case "$port" in ''|*[!0-9]*) die "--port must be numeric" ;; esac
      shift 2
      ;;
    --hostkey-dir) [ "$#" -ge 2 ] || die "--hostkey-dir requires an argument"; hostkey_dir="$2"; shift 2 ;;
    --authorized-keys) [ "$#" -ge 2 ] || die "--authorized-keys requires an argument"; authorized_keys="$2"; shift 2 ;;
    --root-home) [ "$#" -ge 2 ] || die "--root-home requires an argument"; root_home="$2"; shift 2 ;;
    --sftp-server) [ "$#" -ge 2 ] || die "--sftp-server requires an argument"; sftp_server="$2"; shift 2 ;;
    --pidfile) [ "$#" -ge 2 ] || die "--pidfile requires an argument"; pidfile="$2"; shift 2 ;;
    --password-auth) [ "$#" -ge 2 ] || die "--password-auth requires yes or no"; password_auth="$2"; shift 2 ;;
    --root-password-auth) [ "$#" -ge 2 ] || die "--root-password-auth requires yes or no"; root_password_auth="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    --) shift; break ;;
    *) die "unknown option: $1" ;;
  esac
done

case "$password_auth" in yes|no) ;; *) die "--password-auth must be yes or no" ;; esac
case "$root_password_auth" in yes|no) ;; *) die "--root-password-auth must be yes or no" ;; esac

"/usr/generate-host-keys.sh" "$hostkey_dir"

mkdir -p "$root_home/.ssh"
chmod 700 "$root_home/.ssh"
if [ -n "$authorized_keys" ] && [ "$authorized_keys" != "$root_home/.ssh/authorized_keys" ]; then
  if [ -e "$authorized_keys" ]; then
    ln -sf "$authorized_keys" "$root_home/.ssh/authorized_keys"
  fi
fi
[ -e "$root_home/.ssh/authorized_keys" ] && chmod 600 "$root_home/.ssh/authorized_keys"

if [ -n "$sftp_server" ] && [ "$sftp_server" != "$compiled_sftp_server" ]; then
  mkdir -p "${compiled_sftp_server%/*}"
  ln -sf "$sftp_server" "$compiled_sftp_server"
fi

set -- -F -E -P "$pidfile" \
  -r "$hostkey_dir/dropbear_ed25519_host_key" \
  -r "$hostkey_dir/dropbear_rsa_host_key" "$@"

if [ -n "$listen" ]; then
  set -- "$@" -p "$listen:$port"
else
  set -- "$@" -p "$port"
fi

[ "$password_auth" = no ] && set -- "$@" -s
[ "$root_password_auth" = no ] && set -- "$@" -g

exec "/usr/sbin/dropbear" "$@"

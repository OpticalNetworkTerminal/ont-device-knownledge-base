#!/bin/sh
set -eu
hostkey_dir="${1:-/etc/dropbear}"
mkdir -p "$hostkey_dir"
chmod 700 "$hostkey_dir"
[ -s "$hostkey_dir/dropbear_ed25519_host_key" ] ||
  "/usr/bin/dropbearkey" -t ed25519 -f "$hostkey_dir/dropbear_ed25519_host_key"
[ -s "$hostkey_dir/dropbear_rsa_host_key" ] ||
  "/usr/bin/dropbearkey" -t rsa -s 3072 -f "$hostkey_dir/dropbear_rsa_host_key"

#!/bin/sh
set -eu
mkdir -p "/usr/etc/ssh"
chmod 700 "/usr/etc/ssh"
[ -s "/usr/etc/ssh/ssh_host_ed25519_key" ] ||
  "/usr/bin/ssh-keygen" -q -t ed25519 -N ''     -f "/usr/etc/ssh/ssh_host_ed25519_key"
[ -s "/usr/etc/ssh/ssh_host_rsa_key" ] ||
  "/usr/bin/ssh-keygen" -q -t rsa -b 3072 -N ''     -f "/usr/etc/ssh/ssh_host_rsa_key"

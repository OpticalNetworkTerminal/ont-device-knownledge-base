#!/bin/sh
set -eu

die(){ echo "ERROR: $*" >&2; exit 1; }

usage(){
cat <<'USAGE'
Usage:
  start-sshd.sh [--listen IP] [--port PORT] [-- SSHD_ARGS...]

Examples:
  start-sshd.sh
  start-sshd.sh --listen 192.168.1.1 --port 2224
  start-sshd.sh -- -ddd
USAGE
}

listen=""
port=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    --listen|-l)
      [ "$#" -ge 2 ] || die "--listen requires an argument"
      listen="$2"
      shift 2
      ;;
    --port|-p)
      [ "$#" -ge 2 ] || die "--port requires an argument"
      port="$2"
      case "$port" in
        ''|*[!0-9]*) die "--port must be numeric" ;;
      esac
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    --)
      shift
      break
      ;;
    *)
      die "unknown option: $1"
      ;;
  esac
done

mkdir -p "/var/empty"
chown 0:0 "/var/empty"
chmod 755 "/var/empty"

set -- -D -e -f "/usr/etc/ssh/sshd_config" "$@"
[ -n "$port" ] && set -- "$@" -p "$port"
[ -n "$listen" ] && set -- "$@" -o "ListenAddress=$listen"

exec "/usr/sbin/sshd" "$@"

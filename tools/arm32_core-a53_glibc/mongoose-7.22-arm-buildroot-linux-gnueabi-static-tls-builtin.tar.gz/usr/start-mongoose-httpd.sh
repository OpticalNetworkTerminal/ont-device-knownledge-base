#!/bin/sh
set -eu

listen="http://0.0.0.0:8000"
root_dir="/tmp/www"
cert_file="/etc/mongoose/certificate.pem"
key_file="/etc/mongoose/key.pem"

usage(){
cat <<'USAGE'
Usage:
  start-mongoose-httpd.sh [--listen URL] [--root DIR] [--cert FILE --key FILE] [-- MONGOOSE_HTTPD_ARGS...]

Examples:
  start-mongoose-httpd.sh --listen http://0.0.0.0:8000 --root /tmp/www
  start-mongoose-httpd.sh --listen https://0.0.0.0:8443 --cert /etc/mongoose/certificate.pem --key /etc/mongoose/key.pem
USAGE
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --listen) [ "$#" -ge 2 ] || { echo "ERROR: --listen requires an argument" >&2; exit 1; }; listen="$2"; shift 2 ;;
    --root) [ "$#" -ge 2 ] || { echo "ERROR: --root requires an argument" >&2; exit 1; }; root_dir="$2"; shift 2 ;;
    --cert) [ "$#" -ge 2 ] || { echo "ERROR: --cert requires an argument" >&2; exit 1; }; cert_file="$2"; shift 2 ;;
    --key) [ "$#" -ge 2 ] || { echo "ERROR: --key requires an argument" >&2; exit 1; }; key_file="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    --) shift; break ;;
    *) echo "ERROR: unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

mkdir -p "$root_dir"
case "$listen" in
  https://*) exec "/usr/bin/mongoose-httpd" --listen "$listen" --root "$root_dir" --cert "$cert_file" --key "$key_file" "$@" ;;
  *) exec "/usr/bin/mongoose-httpd" --listen "$listen" --root "$root_dir" "$@" ;;
esac

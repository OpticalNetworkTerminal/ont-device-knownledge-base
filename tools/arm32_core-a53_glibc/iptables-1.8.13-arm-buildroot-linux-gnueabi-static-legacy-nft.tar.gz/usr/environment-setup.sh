#!/bin/sh
IPTABLES_ROOT="/usr"
export PATH="$IPTABLES_ROOT/sbin:$PATH"
export XTABLES_LIBDIR="$IPTABLES_ROOT/lib/xtables"
if [ "static" = "dynamic" ]; then
    export LD_LIBRARY_PATH="$IPTABLES_ROOT/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
fi
